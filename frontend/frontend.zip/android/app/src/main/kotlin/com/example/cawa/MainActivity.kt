package com.example.cawa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
