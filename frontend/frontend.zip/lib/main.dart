import 'package:flutter/material.dart';
import 'Splash Screen/SplashScreen.dart';

void main(){
  runApp(const SplashScreen());
}
